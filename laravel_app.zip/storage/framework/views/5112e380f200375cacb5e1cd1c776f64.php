<div class="container" style="margin-top: 150px">
    <p class="d-flex justify-content-center">Todos os direitos reservados 2025</p>
</div><?php /**PATH /home/aragao/repository/gestao-de-trafego/app/resources/views/components/footersite.blade.php ENDPATH**/ ?>