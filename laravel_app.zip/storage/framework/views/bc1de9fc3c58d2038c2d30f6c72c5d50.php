<?php if (isset($component)) { $__componentOriginal471c64e2e1db265ff0ca21fe6000f810 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal471c64e2e1db265ff0ca21fe6000f810 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.navbarsite','data' => ['title' => 'Planos']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('navbarsite'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Planos']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal471c64e2e1db265ff0ca21fe6000f810)): ?>
<?php $attributes = $__attributesOriginal471c64e2e1db265ff0ca21fe6000f810; ?>
<?php unset($__attributesOriginal471c64e2e1db265ff0ca21fe6000f810); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal471c64e2e1db265ff0ca21fe6000f810)): ?>
<?php $component = $__componentOriginal471c64e2e1db265ff0ca21fe6000f810; ?>
<?php unset($__componentOriginal471c64e2e1db265ff0ca21fe6000f810); ?>
<?php endif; ?>
<div class="container">
    <h3 style="margin-top: 30px">Conheça nossos planos</h3>
    <div class="row" style="margin-top: 30px">
        <!-- Plano VIP -->
        <div class="col-md-4 mb-3">
            <div class="card text-center">
                <div class="card-body">
                    <h5 class="card-title">Plano VIP</h5>
                    <p class="card-text">✅ Cadastro comum na plataforma sem taxa de comissão 0%</p>
                    <h4 class="text-primary">R$ 89,90/mês</h4><br>
                    <a href="#" class="btn btn-primary">Assinar</a>
                </div>
            </div>
        </div>
        
        <!-- Plano Primmum -->
        <div class="col-md-4 mb-3">
            <div class="card text-center">
                <div class="card-body">
                    <h5 class="card-title">Plano Prime</h5>
                    <p class="card-text">✅ Aparece no topo do ranking sem taxa de comissão 0%</p>
                    <h4 class="text-primary">R$ 129,90/mês</h4><br>
                    <a href="#" class="btn btn-success">Assinar</a>
                </div>
            </div>
        </div>

        <!-- Plano Master Class -->
        <div class="col-md-4 mb-3">
            <div class="card text-center border-warning">
                <div class="card-body">
                    <h5 class="card-title">Plano Master Class ⭐</h5>
                    <p class="card-text">✅ Topo do ranking + Selo de verificação + Destaque sem taxa de comissão 0%</p>
                    <h4 class="text-warning">R$ 249,90/mês</h4><br>
                    <a href="#" class="btn btn-warning text-white pulse-button">Assinar</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php if (isset($component)) { $__componentOriginal5d584450c3e06ec5a4cd2ffcf655872d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5d584450c3e06ec5a4cd2ffcf655872d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.footersite','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('footersite'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5d584450c3e06ec5a4cd2ffcf655872d)): ?>
<?php $attributes = $__attributesOriginal5d584450c3e06ec5a4cd2ffcf655872d; ?>
<?php unset($__attributesOriginal5d584450c3e06ec5a4cd2ffcf655872d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5d584450c3e06ec5a4cd2ffcf655872d)): ?>
<?php $component = $__componentOriginal5d584450c3e06ec5a4cd2ffcf655872d; ?>
<?php unset($__componentOriginal5d584450c3e06ec5a4cd2ffcf655872d); ?>
<?php endif; ?>

<!-- CSS para efeito de brilho pulsante -->
<style>
    .pulse-button {
        position: relative;
        font-weight: bold;
        transition: 0.3s;
        box-shadow: 0 0 10px rgba(255, 193, 7, 0.8);
        animation: pulse 1.5s infinite alternate;
    }

    @keyframes pulse {
        0% {
            box-shadow: 0 0 10px rgba(255, 193, 7, 0.8);
        }
        100% {
            box-shadow: 0 0 20px rgba(255, 193, 7, 1), 0 0 30px rgba(255, 193, 7, 0.8);
        }
    }
</style>
<?php /**PATH /home/aragao/repository/gestao-de-trafego/app/resources/views/site/price.blade.php ENDPATH**/ ?>